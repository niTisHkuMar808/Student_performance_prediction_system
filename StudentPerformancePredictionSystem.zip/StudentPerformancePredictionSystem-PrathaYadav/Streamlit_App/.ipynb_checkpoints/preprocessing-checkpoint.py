"""
===========================================================
Student Performance Prediction System
Preprocessing Module
===========================================================

This module is responsible for:
1. Loading preprocessing objects.
2. Encoding categorical features.
3. Scaling numerical features.
4. Returning processed data for prediction.
"""

import joblib
import pandas as pd
import numpy as np
from pathlib import Path


# ===========================================================
# Model Directory
# ===========================================================

MODEL_DIR = Path(__file__).resolve().parent.parent / "Model"


# ===========================================================
# Load Saved Objects
# ===========================================================

scaler = joblib.load(MODEL_DIR / "scaler.pkl")
encoder = joblib.load(MODEL_DIR / "encoder.pkl")
feature_names = joblib.load(MODEL_DIR / "feature_names.pkl")


# ===========================================================
# Feature Lists
# ===========================================================

NUMERICAL_FEATURES = [
    "Age",
    "Attendance_Percentage",
    "Study_Hours_Per_Day",
    "Assignment_Avg",
    "Quiz_Avg",
    "Internal_Assessment",
    "Previous_Semester_Percentage",
    "Project_Score",
    "Class_Participation",
    "Extracurricular_Hours",
    "Internet_Hours_Per_Day",
    "Sleep_Hours"
]

CATEGORICAL_FEATURES = [
    "Gender",
    "Family_Support"
]


# ===========================================================
# Preprocess Input Data
# ===========================================================

def preprocess_input(input_df: pd.DataFrame) -> np.ndarray:
    """
    Preprocess user input before prediction.

    Parameters
    ----------
    input_df : pd.DataFrame
        Raw input dataframe.

    Returns
    -------
    np.ndarray
        Processed feature array.
    """

    # ----------------------------
    # Numerical Features
    # ----------------------------
    numerical_data = scaler.transform(
        input_df[NUMERICAL_FEATURES]
    )

    # ----------------------------
    # Categorical Features
    # ----------------------------
    categorical_data = encoder.transform(
        input_df[CATEGORICAL_FEATURES]
    )

    # ----------------------------
    # Combine
    # ----------------------------
    processed = np.concatenate(
        [numerical_data, categorical_data],
        axis=1
    )

    return processed