"""
===========================================================
Student Performance Prediction System
Prediction Module
===========================================================

This module loads the trained model and provides
a function to generate predictions.
"""

import joblib
from pathlib import Path

from preprocessing import preprocess_input

# ===========================================================
# Model Path
# ===========================================================

MODEL_DIR = Path(__file__).resolve().parent.parent / "Model"

# ===========================================================
# Load Best Model
# ===========================================================

model = joblib.load(MODEL_DIR / "best_model.pkl")


# ===========================================================
# Prediction Function
# ===========================================================

def predict_student_performance(input_df):
    """
    Predict student final percentage.

    Parameters
    ----------
    input_df : pandas.DataFrame

    Returns
    -------
    float
        Predicted Final Percentage
    """

    processed_data = preprocess_input(input_df)

    prediction = model.predict(processed_data)

    return round(float(prediction[0]), 2)