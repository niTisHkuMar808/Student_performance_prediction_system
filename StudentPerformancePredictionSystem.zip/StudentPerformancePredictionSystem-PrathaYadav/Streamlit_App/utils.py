"""
===========================================================
Student Performance Prediction System
Utility Functions
===========================================================
"""

import pandas as pd


def create_input_dataframe(
    age,
    gender,
    attendance,
    study_hours,
    assignment_avg,
    quiz_avg,
    internal_assessment,
    previous_semester_percentage,
    project_score,
    class_participation,
    extracurricular_hours,
    internet_hours,
    sleep_hours,
    family_support,
):
    """
    Convert Streamlit user inputs into a pandas DataFrame.
    """

    data = {
        "Age": [age],
        "Gender": [gender],
        "Attendance_Percentage": [attendance],
        "Study_Hours_Per_Day": [study_hours],
        "Assignment_Avg": [assignment_avg],
        "Quiz_Avg": [quiz_avg],
        "Internal_Assessment": [internal_assessment],
        "Previous_Semester_Percentage": [previous_semester_percentage],
        "Project_Score": [project_score],
        "Class_Participation": [class_participation],
        "Extracurricular_Hours": [extracurricular_hours],
        "Internet_Hours_Per_Day": [internet_hours],
        "Sleep_Hours": [sleep_hours],
        "Family_Support": [family_support],
    }

    return pd.DataFrame(data)