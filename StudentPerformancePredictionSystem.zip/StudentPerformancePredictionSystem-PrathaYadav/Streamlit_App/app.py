import streamlit as st

from utils import create_input_dataframe
from prediction import predict_student_performance

# ============================================================
# Page Configuration
# ============================================================

st.set_page_config(
    page_title="Student Performance Prediction System",
    page_icon="🎓",
    layout="wide",
)

# ============================================================
# Sidebar
# ============================================================

st.sidebar.title("🎓 Student Performance Prediction")

st.sidebar.markdown("""
This application predicts a student's **Final Percentage**
using a trained Machine Learning model.

**Internship Capstone Project**

Technology Stack:
- Python
- Scikit-learn
- XGBoost
- Streamlit
""")

# ============================================================
# Main Title
# ============================================================

st.title("🎓 Student Performance Prediction System")

st.write(
    "Enter the student's academic details and click **Predict**."
)

# ============================================================
# Input Form
# ============================================================

with st.form("prediction_form"):

    col1, col2 = st.columns(2)

    with col1:

        age = st.number_input(
            "Age",
            min_value=15,
            max_value=35,
            value=20,
        )

        gender = st.selectbox(
            "Gender",
            ["Male", "Female"],
        )

        attendance = st.slider(
            "Attendance Percentage",
            0,
            100,
            80,
        )

        study_hours = st.slider(
            "Study Hours Per Day",
            0.0,
            12.0,
            4.0,
        )

        assignment_avg = st.slider(
            "Assignment Average",
            0,
            100,
            75,
        )

        quiz_avg = st.slider(
            "Quiz Average",
            0,
            100,
            75,
        )

        internal = st.slider(
            "Internal Assessment",
            0,
            100,
            75,
        )

    with col2:

        previous = st.slider(
            "Previous Semester Percentage",
            0,
            100,
            75,
        )

        project = st.slider(
            "Project Score",
            0,
            100,
            80,
        )

        participation = st.slider(
            "Class Participation",
            0,
            10,
            5,
        )

        extracurricular = st.slider(
            "Extracurricular Hours",
            0,
            20,
            2,
        )

        internet = st.slider(
            "Internet Hours Per Day",
            0.0,
            12.0,
            3.0,
        )

        sleep = st.slider(
            "Sleep Hours",
            2.0,
            12.0,
            7.0,
        )

        family = st.selectbox(
            "Family Support",
            ["Low", "Medium", "High"],
        )

    predict_button = st.form_submit_button("Predict")
    reset_button = st.form_submit_button("Reset")

# ============================================================
# Prediction
# ============================================================

if predict_button:

    try:

        input_df = create_input_dataframe(
            age,
            gender,
            attendance,
            study_hours,
            assignment_avg,
            quiz_avg,
            internal,
            previous,
            project,
            participation,
            extracurricular,
            internet,
            sleep,
            family,
        )

        prediction = predict_student_performance(input_df)

        st.success(
            f"🎯 Predicted Final Percentage: {prediction:.2f}%"
        )

    except Exception as e:
        st.error(f"Prediction Error: {e}")

if reset_button:
    st.rerun()