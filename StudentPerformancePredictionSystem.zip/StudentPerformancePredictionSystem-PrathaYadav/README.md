# 🎓 Student Performance Prediction System

## Overview

This project predicts a student's final academic percentage using Machine Learning.

It was developed as a Summer Internship Capstone Project.

---

## Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- XGBoost
- Streamlit

---

## Machine Learning Workflow

- Data Understanding
- Data Cleaning
- Exploratory Data Analysis
- Feature Engineering
- Model Training
- Hyperparameter Tuning
- Model Evaluation
- Model Deployment using Streamlit

---

## Project Structure

```
Student_Performance_Prediction_System/

├── Dataset/
├── Notebook/
├── Model/
├── Streamlit_App/
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Models Trained

- Linear Regression
- Random Forest Regressor
- XGBoost Regressor

Best Model:
**Linear Regression**

---

## Evaluation Metrics

- MAE
- MSE
- RMSE
- R² Score
- Cross Validation

---

## Run the Project

Install dependencies:

```bash
pip install -r requirements.txt
```

Start Streamlit:

```bash
cd Streamlit_App
streamlit run app.py
```

---

## Author

Summer Internship Machine Learning Capstone Project