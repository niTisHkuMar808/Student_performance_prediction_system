import pandas as pd

from Streamlit_App.prediction import predict_student_performance

sample = pd.DataFrame({
    "Age": [20],
    "Attendance_Percentage": [90],
    "Study_Hours_Per_Day": [4],
    "Assignment_Avg": [85],
    "Quiz_Avg": [80],
    "Internal_Assessment": [88],
    "Previous_Semester_Percentage": [82],
    "Project_Score": [90],
    "Class_Participation": [8],
    "Extracurricular_Hours": [2],
    "Internet_Hours_Per_Day": [3],
    "Sleep_Hours": [7],
    "Gender": ["Male"],
    "Family_Support": ["High"]
})

prediction = predict_student_performance(sample)

print("Predicted Final Percentage:", prediction)